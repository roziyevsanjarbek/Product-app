<?php

use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});


//Route::get('/admin/dashboard', [HomeController::class, 'index']);
//Route::get('/user/dashboard', [HomeController::class, 'userDashboard']);


Route::get('/login', [HomeController::class, 'login'])->name('login');

Route::get('/admin/dashboard', [HomeController::class, 'dashboard'])->name('dashboard');
Route::get('/admin/products', [HomeController::class, 'products'])->name('products');
Route::get('/admin/sold', [HomeController::class, 'sold'])->name('sold');
Route::get('/admin/users', [HomeController::class, 'users'])->name('users');

Route::get('/user/dashboard', [HomeController::class, 'userDashboard'])->name('userDashboard');
Route::get('/user/products', [HomeController::class, 'userProducts'])->name('userProducts');
Route::get('/user/sold', [HomeController::class, 'userSold'])->name('userSold');
