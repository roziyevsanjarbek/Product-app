<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mahsulot Boshqaruvi Tizimi</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #1f2937;
            --secondary: #111827;
            --accent: #3b82f6;
            --accent-light: #60a5fa;
            --border: #374151;
            --text-primary: #f3f4f6;
            --text-secondary: #d1d5db;
            --success: #10b981;
            --danger: #ef4444;
            --bg: #0f172a;
            --card: #1e293b;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
            background-color: var(--bg);
            color: var(--text-primary);
            line-height: 1.6;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background-color: var(--primary);
            border-right: 1px solid var(--border);
            padding: 20px 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid var(--border);
            margin-bottom: 20px;
            text-align: center;
        }

        .sidebar-header h2 {
            font-size: 18px;
            color: var(--accent);
        }

        .nav-item {
            padding: 15px 20px;
            cursor: pointer;
            transition: all 0.3s;
            border-left: 3px solid transparent;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .nav-item:hover {
            background-color: var(--secondary);
            border-left-color: var(--accent);
        }

        .nav-item.active {
            background-color: var(--secondary);
            border-left-color: var(--accent);
            color: var(--accent);
        }

        /* Main Content */
        .main-content {
            margin-left: 250px;
            flex: 1;
            padding: 30px;
        }

        .page {
            display: none;
        }

        .page.active {
            display: block;
        }

        h1 {
            font-size: 28px;
            margin-bottom: 30px;
            color: var(--accent);
        }

        /* Dashboard Stats */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .stat-card {
            background-color: var(--card);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 20px;
            transition: all 0.3s;
        }

        .stat-card:hover {
            border-color: var(--accent);
            transform: translateY(-2px);
        }

        .stat-card h3 {
            font-size: 14px;
            color: var(--text-secondary);
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stat-value {
            font-size: 32px;
            font-weight: bold;
            color: var(--accent);
            margin-bottom: 5px;
        }

        .stat-label {
            font-size: 13px;
            color: var(--text-secondary);
        }

        /* Forms */
        .form-container {
            background-color: var(--card);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 25px;
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-size: 14px;
            margin-bottom: 8px;
            color: var(--text-secondary);
            font-weight: 500;
        }

        input, select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid var(--border);
            border-radius: 6px;
            background-color: var(--primary);
            color: var(--text-primary);
            font-size: 14px;
            transition: all 0.3s;
        }

        input:focus, select:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        /* Buttons */
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s;
            font-weight: 500;
        }

        .btn-primary {
            background-color: var(--accent);
            color: white;
        }

        .btn-primary:hover {
            background-color: var(--accent-light);
        }

        .btn-danger {
            background-color: var(--danger);
            color: white;
            padding: 5px 10px;
            font-size: 12px;
        }

        .btn-danger:hover {
            opacity: 0.8;
        }

        /* Tables */
        .table-container {
            background-color: var(--card);
            border: 1px solid var(--border);
            border-radius: 8px;
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background-color: var(--primary);
            border-bottom: 1px solid var(--border);
        }

        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 13px;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid var(--border);
            font-size: 14px;
        }

        tr:hover {
            background-color: var(--primary);
        }

        .badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }

        .badge-admin {
            background-color: rgba(59, 130, 246, 0.2);
            color: var(--accent);
        }

        .badge-user {
            background-color: rgba(16, 185, 129, 0.2);
            color: var(--success);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-secondary);
        }

        .empty-state p {
            font-size: 16px;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 60px;
            }

            .sidebar-header h2 {
                font-size: 12px;
            }

            .nav-item {
                padding: 15px 10px;
                justify-content: center;
            }

            .main-content {
                margin-left: 60px;
                padding: 15px;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h2>MBT</h2>
        </div>
        <div class="nav-item active" onclick="showPage('dashboard', this)">
            📊 Dashboard
        </div>
        <div class="nav-item" onclick="showPage('products', this)">
            📦 Mahsulotlar
        </div>
        <div class="nav-item" onclick="showPage('sold', this)">
            💰 Sotilganlar
        </div>
        <div class="nav-item" onclick="showPage('users', this)">
            👥 Foydalanuvchilar
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Dashboard Page -->
        <div id="dashboard" class="page active">
            <h1>Dashboard</h1>
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Mavjud Mahsulotlar</h3>
                    <div class="stat-value" id="totalProducts">0</div>
                    <div class="stat-label" id="totalProductsValue">Jami qiymati: 0 so'm</div>
                </div>
                <div class="stat-card">
                    <h3>Sotilgan Mahsulotlar</h3>
                    <div class="stat-value" id="soldCount">0</div>
                    <div class="stat-label" id="soldValue">Jami daromad: 0 so'm</div>
                </div>
                <div class="stat-card">
                    <h3>Qolgan Mahsulotlar</h3>
                    <div class="stat-value" id="remainingCount">0</div>
                    <div class="stat-label" id="remainingValue">Qolgan qiymati: 0 so'm</div>
                </div>
                <div class="stat-card">
                    <h3>Jami Foydalanuvchilar</h3>
                    <div class="stat-value" id="userCount">0</div>
                    <div class="stat-label">Sistemada roʻyxatdan oʻtgan</div>
                </div>
            </div>
        </div>

        <!-- Products Page -->
        <div id="products" class="page">
            <h1>Mahsulotlarni Qoʻshish</h1>
            <div class="form-container">
                <form id="productForm">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Mahsulot Nomi</label>
                            <input type="text" id="productName" placeholder="Masalan: Kiyim" required>
                        </div>
                        <div class="form-group">
                            <label>Sonı (dona)</label>
                            <input type="number" id="productQty" placeholder="0" min="1" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Narxi (so'm)</label>
                            <input type="number" id="productPrice" placeholder="0" min="1" required>
                        </div>
                        <div class="form-group">
                            <label>Qoʻshgan User</label>
                            <select id="productUser" required>
                                <option value="">Foydalanuvchi tanlang</option>
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Mahsulot Qoʻshish</button>
                </form>
            </div>

            <div class="table-container">
                <table>
                    <thead>
                    <tr>
                        <th>Mahsulot Nomi</th>
                        <th>Sonı</th>
                        <th>Narxi (so'm)</th>
                        <th>Jami (so'm)</th>
                        <th>Qoʻshgan User</th>
                        <th>Sana</th>
                        <th>Amal</th>
                    </tr>
                    </thead>
                    <tbody id="productTableBody">
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px;">Mahsulot qoʻshilmagan</td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Sold Products Page -->
        <div id="sold" class="page">
            <h1>Sotilgan Mahsulotlar</h1>
            <div class="form-container">
                <form id="soldForm">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Mahsulot Tanlang</label>
                            <select id="soldProduct" required>
                                <option value="">Mahsulot tanlang</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Sotilgan Sonı</label>
                            <input type="number" id="soldQty" placeholder="0" min="1" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Sotgan User</label>
                            <select id="soldUser" required>
                                <option value="">Foydalanuvchi tanlang</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Sotilgan Narxi (so'm)</label>
                            <input type="number" id="soldPrice" placeholder="0" min="1" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Sotilgan Mahsulot Qoʻshish</button>
                </form>
            </div>

            <div class="table-container">
                <table>
                    <thead>
                    <tr>
                        <th>Mahsulot Nomi</th>
                        <th>Sotilgan Sonı</th>
                        <th>Birlik Narxi (so'm)</th>
                        <th>Jami (so'm)</th>
                        <th>Sotgan User</th>
                        <th>Sana</th>
                        <th>Amal</th>
                    </tr>
                    </thead>
                    <tbody id="soldTableBody">
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px;">Sotilgan mahsulot qoʻshilmagan</td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Users Page -->
        <div id="users" class="page">
            <h1>Foydalanuvchilar Boshqaruvi</h1>
            <div class="form-container">
                <form id="userForm">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Foydalanuvchi Nomi</label>
                            <input type="text" id="userName" placeholder="Nomi Familiyasi" required>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" id="userEmail" placeholder="email@example.com" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Roli</label>
                            <select id="userRole" required>
                                <option value="user">Foydalanuvchi</option>
                                <option value="admin">Administrator</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Telefon</label>
                            <input type="tel" id="userPhone" placeholder="+998 XX XXX XX XX" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Foydalanuvchi Qoʻshish</button>
                </form>
            </div>

            <div class="table-container">
                <table>
                    <thead>
                    <tr>
                        <th>Nomi</th>
                        <th>Email</th>
                        <th>Telefon</th>
                        <th>Roli</th>
                        <th>Qoʻshilgan Sana</th>
                        <th>Amal</th>
                    </tr>
                    </thead>
                    <tbody id="userTableBody">
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px;">Foydalanuvchi qoʻshilmagan</td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    // Data Storage
    let products = JSON.parse(localStorage.getItem('products')) || [];
    let soldProducts = JSON.parse(localStorage.getItem('soldProducts')) || [];
    let users = JSON.parse(localStorage.getItem('users')) || [];

    // Page Navigation
    function showPage(pageName, navElement) {
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        document.getElementById(pageName).classList.add('active');

        document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
        navElement.classList.add('active');

        if (pageName === 'dashboard') {
            updateDashboard();
        } else if (pageName === 'products' || pageName === 'sold') {
            updateUserSelects();
            refreshTables();
        } else if (pageName === 'users') {
            refreshTables();
        }
    }

    // Update Dashboard
    function updateDashboard() {
        const totalQty = products.reduce((sum, p) => sum + p.quantity, 0);
        const totalValue = products.reduce((sum, p) => sum + (p.quantity * p.price), 0);

        const soldQty = soldProducts.reduce((sum, p) => sum + p.quantity, 0);
        const soldValue = soldProducts.reduce((sum, p) => sum + p.totalPrice, 0);

        const remainingQty = totalQty - soldQty;
        const remainingValue = totalValue - soldValue;

        document.getElementById('totalProducts').textContent = totalQty;
        document.getElementById('totalProductsValue').textContent = `Jami qiymati: ${totalValue.toLocaleString()} so'm`;

        document.getElementById('soldCount').textContent = soldQty;
        document.getElementById('soldValue').textContent = `Jami daromad: ${soldValue.toLocaleString()} so'm`;

        document.getElementById('remainingCount').textContent = remainingQty;
        document.getElementById('remainingValue').textContent = `Qolgan qiymati: ${remainingValue.toLocaleString()} so'm`;

        document.getElementById('userCount').textContent = users.length;
    }

    // Update User Selects
    function updateUserSelects() {
        const selects = ['productUser', 'soldUser'];
        selects.forEach(selectId => {
            const select = document.getElementById(selectId);
            const currentValue = select.value;
            select.innerHTML = '<option value="">Foydalanuvchi tanlang</option>';
            users.forEach(user => {
                const option = document.createElement('option');
                option.value = user.id;
                option.textContent = user.name;
                select.appendChild(option);
            });
            select.value = currentValue;
        });

        const soldProductSelect = document.getElementById('soldProduct');
        const currentProduct = soldProductSelect.value;
        soldProductSelect.innerHTML = '<option value="">Mahsulot tanlang</option>';
        products.forEach(product => {
            const option = document.createElement('option');
            option.value = product.id;
            option.textContent = `${product.name} (${product.quantity} dona)`;
            soldProductSelect.appendChild(option);
        });
        soldProductSelect.value = currentProduct;
    }

    // Refresh Tables
    function refreshTables() {
        refreshProductTable();
        refreshSoldTable();
        refreshUserTable();
    }

    function refreshProductTable() {
        const tbody = document.getElementById('productTableBody');
        if (products.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 40px;">Mahsulot qoʻshilmagan</td></tr>';
            return;
        }

        tbody.innerHTML = products.map(p => {
            const user = users.find(u => u.id === p.userId);
            const total = p.quantity * p.price;
            return `
                    <tr>
                        <td>${p.name}</td>
                        <td>${p.quantity}</td>
                        <td>${p.price.toLocaleString()}</td>
                        <td>${total.toLocaleString()}</td>
                        <td>${user ? user.name : 'Noma`lum'}</td>
                        <td>${new Date(p.date).toLocaleDateString('uz-UZ')}</td>
                        <td><button class="btn btn-danger" onclick="deleteProduct('${p.id}')">Oʻchirish</button></td>
                    </tr>
                `;
        }).join('');
    }

    function refreshSoldTable() {
        const tbody = document.getElementById('soldTableBody');
        if (soldProducts.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 40px;">Sotilgan mahsulot qoʻshilmagan</td></tr>';
            return;
        }

        tbody.innerHTML = soldProducts.map(p => {
            const product = products.find(pr => pr.id === p.productId);
            const user = users.find(u => u.id === p.userId);
            return `
                    <tr>
                        <td>${product ? product.name : 'Noma`lum'}</td>
                        <td>${p.quantity}</td>
                        <td>${p.unitPrice.toLocaleString()}</td>
                        <td>${p.totalPrice.toLocaleString()}</td>
                        <td>${user ? user.name : 'Noma`lum'}</td>
                        <td>${new Date(p.date).toLocaleDateString('uz-UZ')}</td>
                        <td><button class="btn btn-danger" onclick="deleteSold('${p.id}')">Oʻchirish</button></td>
                    </tr>
                `;
        }).join('');
    }

    function refreshUserTable() {
        const tbody = document.getElementById('userTableBody');
        if (users.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 40px;">Foydalanuvchi qoʻshilmagan</td></tr>';
            return;
        }

        tbody.innerHTML = users.map(u => `
                <tr>
                    <td>${u.name}</td>
                    <td>${u.email}</td>
                    <td>${u.phone}</td>
                    <td><span class="badge badge-${u.role === 'admin' ? 'admin' : 'user'}">${u.role === 'admin' ? 'Admin' : 'Foydalanuvchi'}</span></td>
                    <td>${new Date(u.date).toLocaleDateString('uz-UZ')}</td>
                    <td><button class="btn btn-danger" onclick="deleteUser('${u.id}')">Oʻchirish</button></td>
                </tr>
            `).join('');
    }

    // Delete Functions
    function deleteProduct(id) {
        if (confirm('Shunga ishonchingiz komilmi?')) {
            products = products.filter(p => p.id !== id);
            localStorage.setItem('products', JSON.stringify(products));
            refreshProductTable();
            updateDashboard();
        }
    }

    function deleteSold(id) {
        if (confirm('Shunga ishonchingiz komilmi?')) {
            soldProducts = soldProducts.filter(p => p.id !== id);
            localStorage.setItem('soldProducts', JSON.stringify(soldProducts));
            refreshSoldTable();
            updateDashboard();
        }
    }

    function deleteUser(id) {
        if (confirm('Shunga ishonchingiz komilmi?')) {
            users = users.filter(u => u.id !== id);
            localStorage.setItem('users', JSON.stringify(users));
            refreshUserTable();
        }
    }

    // Form Submissions
    document.getElementById('productForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const product = {
            id: Date.now().toString(),
            name: document.getElementById('productName').value,
            quantity: parseInt(document.getElementById('productQty').value),
            price: parseInt(document.getElementById('productPrice').value),
            userId: document.getElementById('productUser').value,
            date: new Date().toISOString()
        };
        products.push(product);
        localStorage.setItem('products', JSON.stringify(products));
        e.target.reset();
        refreshProductTable();
        updateDashboard();
    });

    document.getElementById('soldForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const sold = {
            id: Date.now().toString(),
            productId: document.getElementById('soldProduct').value,
            quantity: parseInt(document.getElementById('soldQty').value),
            unitPrice: parseInt(document.getElementById('soldPrice').value),
            totalPrice: parseInt(document.getElementById('soldQty').value) * parseInt(document.getElementById('soldPrice').value),
            userId: document.getElementById('soldUser').value,
            date: new Date().toISOString()
        };
        soldProducts.push(sold);
        localStorage.setItem('soldProducts', JSON.stringify(soldProducts));
        e.target.reset();
        refreshSoldTable();
        updateDashboard();
    });

    document.getElementById('userForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const user = {
            id: Date.now().toString(),
            name: document.getElementById('userName').value,
            email: document.getElementById('userEmail').value,
            phone: document.getElementById('userPhone').value,
            role: document.getElementById('userRole').value,
            date: new Date().toISOString()
        };
        users.push(user);
        localStorage.setItem('users', JSON.stringify(users));
        e.target.reset();
        refreshUserTable();
        updateUserSelects();
    });

    // Initial Load
    updateDashboard();
    refreshTables();
</script>
</body>
</html>
<?php /**PATH /home/sanjarbek/project/EGS-product/resources/views/user/user-dashboard.blade.php ENDPATH**/ ?>