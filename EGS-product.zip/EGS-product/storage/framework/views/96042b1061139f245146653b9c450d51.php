<style>
    .sidebar {
        width: 240px;
        background: #1a1a1a;
        color: #fff;
        height: 100vh;
        padding-top: 20px;
    }

    .nav-item {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 14px 20px;
        color: #ddd;
        text-decoration: none;
        font-size: 16px;
        transition: 0.2s ease;
    }

    .nav-item:hover {
        background: #333;
    }

    .nav-item.active {
        background: #4a90e2;
        color: white;
        font-weight: bold;
    }

</style>

<div class="sidebar">
    <div class="sidebar-header">
        <h2>EGS</h2>
    </div>

    <a class="nav-item <?php echo e(request()->is('admin/dashboard') ? 'active' : ''); ?>"
       href="<?php echo e(route('dashboard')); ?>">
        📊 Dashboard
    </a>

    <a class="nav-item <?php echo e(request()->is('admin/products*') ? 'active' : ''); ?>"
       href="/admin/products">
        📦 Mahsulotlar
    </a>

    <a class="nav-item <?php echo e(request()->is('admin/sold*') ? 'active' : ''); ?>"
       href="/admin/sold">
        💰 Sotilganlar
    </a>

    <a class="nav-item <?php echo e(request()->is('admin/users*') ? 'active' : ''); ?>"
       href="/admin/users">
        👥 Foydalanuvchilar
    </a>
</div>
<?php /**PATH /home/sanjarbek/project/EGS-product/resources/views/components/sidebar.blade.php ENDPATH**/ ?>