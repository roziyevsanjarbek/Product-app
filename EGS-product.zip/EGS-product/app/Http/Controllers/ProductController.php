<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{

    public function index(Request $request)
    {
        // Barcha productlar + kim qo‘shgani
        $products = Product::with('creator')
            ->orderBy('created_at', 'desc') // oxirgi qo‘shilganlar yuqorida
            ->get();

        return response()->json([
            'message' => 'Products fetched successfully',
            'data' => $products
        ]);
    }



    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'quantity' => 'required|integer|min:1',
            'price' => 'required|integer|min:1',
        ]);

        $product = Product::create([
            'name' => $request->name,
            'quantity' => $request->quantity,
            'price' => $request->price,
            'created_by' => auth()->id(),
        ]);

        // Kim qo‘shganini yuklab olamiz
        $product->load('creator');

        return response()->json([
            'message' => 'Product successfully created',
            'data' => $product
        ], 201);
    }

    public function update(Request $request, $id)
    {
        $product = Product::find($id);

        if (!$product) {
            return response()->json(['message' => 'Product not found'], 404);
        }
        // Validatsiya
        $request->validate([
            'name' => 'sometimes|required|string|max:255',
            'quantity' => 'sometimes|required|integer|min:0',
            'price' => 'sometimes|required|integer|min:1',
        ]);

        // Faqat null bo‘lmagan maydonlarni olamiz
        $product->name = $request->input('name');
        $product->quantity = $request->input('quantity');
        $product->price = $request->input('price');
        $product->save();


        return response()->json([
            'message' => 'Product updated successfully',
            'data' => $product->load('creator')
        ]);
    }

    public function destroy($id)
    {
        // 1️⃣ Productni topamiz
        $product = Product::find($id);

        if (!$product) {
            return response()->json([
                'message' => 'Product not found'
            ], 404);
        }

        // 2️⃣ Productni o‘chiramiz
        $product->delete();

        return response()->json([
            'message' => 'Product deleted successfully'
        ]);
    }



}
