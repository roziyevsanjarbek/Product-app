<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        return view('admin.index');
    }


    public function dashboard()
    {
        return view('admin.dashboard');
    }

    public function products()
    {
        return view('admin.product');
    }

    public function sold()
    {
        return view('admin.sold');
    }

    public function users()
    {
        return view('admin.users');
    }

    public function userDashboard()
    {
        return view('user.dashboard');
    }

    public function userProducts()
    {
        return view('user.product');
    }

    public function userSold(){
        return view('user.sold');
    }



    public function login()
    {
        return view('login');
    }
}
