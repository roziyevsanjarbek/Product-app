<?php

namespace App\Http\Controllers;

use App\Models\Sales;
use Illuminate\Http\Request;
use App\Models\Product;

class SalesController extends Controller
{
    // Barcha sotuvlarni olish
    public function index()
    {
        $sales = Sales::with(['product', 'creator'])
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json([
            'message' => 'Sales fetched successfully',
            'data' => $sales
        ]);
    }

    // Yangi sotuv qo'shish
    public function store(Request $request)
    {
        $request->validate([
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:1'
        ]);

        $product = Product::find($request->product_id);

        // Tekshiramiz: yetarli product mavjudmi
        if ($request->quantity > $product->quantity) {
            return response()->json([
                'message' => 'Not enough product in stock'
            ], 400);
        }

        // Total price hisoblash
        $totalPrice = $request->quantity * $product->price;

        // Sale yaratish
        $sale = Sales::create([
            'product_id' => $product->id,
            'quantity' => $request->quantity,
            'total_price' => $totalPrice,
            'created_by' => auth()->id(),
        ]);

        // Product miqdorini kamaytirish
        $product->quantity -= $request->quantity;
        $product->save();

        return response()->json([
            'message' => 'Sale added successfully',
            'data' => $sale->load('product', 'creator')
        ], 201);
    }

    public function update(Request $request, $id)
    {
        $sale = Sales::find($id);

        if (!$sale) {
            return response()->json(['message' => 'Sale not found'], 404);
        }

        $request->validate([
            'quantity' => 'required|integer|min:1',
        ]);

        $product = $sale->product;

        // Avvalgi sale miqdorini qaytaramiz productga
        $product->quantity += $sale->quantity;

        // Tekshiramiz: yetarli product mavjudmi
        if ($request->quantity > $product->quantity) {
            return response()->json([
                'message' => 'Not enough product in stock'
            ], 400);
        }

        // Sale miqdorini yangilaymiz
        $sale->quantity = $request->quantity;
        $sale->total_price = $request->quantity * $product->price;
        $sale->save();

        // Product miqdorini kamaytirish
        $product->quantity -= $request->quantity;
        $product->save();

        return response()->json([
            'message' => 'Sale updated successfully',
            'data' => $sale->load('product', 'creator')
        ]);
    }

    public function destroy($id)
    {
        $sale = Sales::find($id);

        if (!$sale) {
            return response()->json(['message' => 'Sale not found'], 404);
        }

        $product = $sale->product;

        // Product miqdorini tiklash
        $product->quantity += $sale->quantity;
        $product->save();

        // Sale o'chirish
        $sale->delete();

        return response()->json([
            'message' => 'Sale deleted successfully'
        ]);
    }


}
