<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    /**
     * Register user
     */
    public function addUser(Request $request)
    {
        $request->validate([
            'name'     => 'required|string|max:255',
            'email'    => 'required|email|unique:users,email',
            'password' => 'required|min:6|',
        ]);

        // 1️⃣ User yaratish
        $user = User::create([
            'name'     => $request->name,
            'email'    => $request->email,
            'password' => Hash::make($request->password),
        ]);

        // 2️⃣ Default role olish yoki yaratish
        $role = Role::firstOrCreate(
            ['name' => 'user'], // agar bunday roli bo'lmasa, yaratadi
            ['description' => 'Default user role'] // agar description kerak bo‘lsa
        );

        // 3️⃣ Pivot jadvalga biriktirish
        $user->roles()->attach($role->id);

        // 4️⃣ Token yaratish
        $token = $user->createToken('auth_token')->plainTextToken;

        return response()->json([
            'message' => 'User registered',
            'access_token' => $token,
            'user' => $user->load('roles'),
            'token_type' => 'Bearer'
        ], 201);
    }

    // UPDATE USER
    public function updateUser(Request $request, $id)
    {
        $user = User::findOrFail($id);

        $request->validate([
            'name'     => 'sometimes|required|string|max:255',
            'email'    => 'sometimes|required|email|unique:users,email,' . $user->id,
            'password' => 'sometimes|min:6',
        ]);

        if ($request->has('name')) {
            $user->name = $request->name;
        }

        if ($request->has('email')) {
            $user->email = $request->email;
        }

        if ($request->has('password')) {
            $user->password = Hash::make($request->password);
        }

        $user->save();

        // Role update (agar kerak bo‘lsa)
        if ($request->has('role')) {
            $role = Role::firstOrCreate(
                ['name' => $request->role],
                ['description' => ucfirst($request->role) . ' role']
            );
            $user->roles()->sync([$role->id]); // eski rollarni o‘chirib yangi rol biriktiradi
        }

        return response()->json([
            'message' => 'User updated successfully',
            'user' => $user->load('roles')
        ]);
    }

    public function show($id) {
        $user = User::find($id);
        if (!$user) {
            return response()->json(['success'=>false, 'message'=>'Foydalanuvchi topilmadi']);
        }
        return response()->json(['success'=>true, 'data'=>$user]);
    }


    // DELETE USER
    public function deleteUser($id)
    {
        $user = User::findOrFail($id);

        // Pivot jadvaldagi rollarni o‘chirish
        $user->roles()->detach();

        // Userni o‘chirish
        $user->delete();

        return response()->json([
            'message' => 'User deleted successfully'
        ]);
    }

    public function user(Request $request)
    {
        $user = $request->user(); // Login qilgan userni olish

        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => 'User not authenticated'
            ], 401);
        }

        return response()->json([
            'success' => true,
            'data' => [$user] // faqat login qilgan user
        ]);
    }





    /**
     * Login user
     */
    public function login(Request $request)
    {
        $request->validate([
            'email'    => 'required|email',
            'password' => 'required',
        ]);

        $user = User::where('email', $request->email)->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            throw ValidationException::withMessages([
                'email' => ['Email yoki parol noto‘g‘ri.'],
            ]);
        }

        $token = $user->createToken('auth_token')->plainTextToken;
        $roles = $user->roles()->pluck('name');
        return response()->json([
            'message' => 'Login successful',
            'access_token' => $token,
            'user' => $user,
            'roles' => $roles,
            'token_type' => 'Bearer'
        ]);
    }


    /**
     * Logout user
     */
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'message' => 'Logged out'
        ]);
    }

    public function index()
    {
        $users = User::query()->orderBy('created_at', 'desc')->get(); // barcha yozuvlar

        return response()->json([
            'success' => true,
            'data' => $users
        ], 200);
    }
}
